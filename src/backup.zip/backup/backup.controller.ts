// src/backup/backup.controller.ts
import { Controller, Post } from '@nestjs/common';
import { BackupService } from './backup.service';

@Controller('backup')
export class BackupController {
  constructor(private readonly backupService: BackupService) {}

  // Endpoint to trigger the backup manually
  @Post()
  async triggerBackup() {
    await this.backupService.triggerBackup();
    return { message: 'Backup triggered successfully!' };
  }
}
