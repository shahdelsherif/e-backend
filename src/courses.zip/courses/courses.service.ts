import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Course } from './course.schema';

@Injectable()
export class CoursesService {
  constructor(@InjectModel(Course.name) private courseModel: Model<Course>) {}

  async create(createCourseDto: Partial<Course>): Promise<Course> {
    const newCourse = new this.courseModel(createCourseDto);
    return newCourse.save(); 
  }

  async findAll(): Promise<Course[]> {
    return this.courseModel.find().exec(); 
  }

  async findMany(ids: string[]): Promise<Course[]> {
    return this.courseModel.find({ '_id': { $in: ids } }).exec();
  }

  async findOne(id: string): Promise<Course> {
    return this.courseModel.findById(id).exec(); 
  }

  async update(id: string, updateCourseDto: Partial<Course>): Promise<Course> {
    return this.courseModel.findByIdAndUpdate(id, updateCourseDto, { new: true }).exec(); // Update a course by ID
  }

  async remove(id: string): Promise<Course> {
    return this.courseModel.findByIdAndDelete(id).exec(); // Remove a course by ID
  }

  // New method to find courses by criteria
  async findManyByCriteria(criteria: any): Promise<Course[]> {
    return this.courseModel.find(criteria).exec(); // Find courses based on the provided criteria
  }
}





/*import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Course } from './course.schema';

@Injectable()
export class CoursesService {
  constructor(@InjectModel(Course.name) private courseModel: Model<Course>) {}

  async create(createCourseDto: Partial<Course>): Promise<Course> {
    const newCourse = new this.courseModel(createCourseDto);
    return newCourse.save(); 
  }

  async findAll(): Promise<Course[]> {
    return this.courseModel.find().exec(); 
  }

  async findMany(ids: string[]): Promise<Course[]> {
    return this.courseModel.find({ '_id': { $in: ids } }).exec();
  }

  async findOne(id: string): Promise<Course> {
    return this.courseModel.findById(id).exec(); 
  }

  async update(id: string, updateCourseDto: Partial<Course>): Promise<Course> {
    return this.courseModel.findByIdAndUpdate(id, updateCourseDto, { new: true }).exec(); // Update a course by ID
  }

  async remove(id: string): Promise<Course> {
    return this.courseModel.findByIdAndDelete(id).exec(); // Remove a course by ID
  }
}*/
