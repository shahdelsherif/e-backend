// src/backup/backup.service.ts
import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { UsersService } from '../users/users.service'; // Assume you have a UsersService
import { CoursesService } from '../courses/courses.service'; // Assume you have a CoursesService

@Injectable()
export class BackupService {
  constructor(
    private readonly usersService: UsersService,
    private readonly coursesService: CoursesService,
  ) {}

  // Manually triggered backup
  async triggerBackup() {
    console.log('Starting data backup...');

    // Backup user data
    const users = await this.usersService.findAll(); // Fetch all users
    this.backupData('users_backup.json', users);

    // Backup course progress data
    const courses = await this.coursesService.findAll(); // Fetch all courses
    this.backupData('courses_backup.json', courses);

    console.log('Data backup completed.');
  }

  // Helper function to save data to a backup file
  private backupData(filename: string, data: any) {
    const backupPath = path.join(__dirname, '..', 'backups', filename);

    // Ensure the backups folder exists
    if (!fs.existsSync(path.dirname(backupPath))) {
      fs.mkdirSync(path.dirname(backupPath));
    }

    // Write data to backup file
    fs.writeFileSync(backupPath, JSON.stringify(data, null, 2), 'utf8');
  }
}
